function showVisitedAnimals() {
    //ממשו את הלוגיקה שמציגה את החיות שהאורח הנוכחי ביקר בהן
  }
  function showFeededAnimals() {
    //ממשו את הלוגיקה שמציגה את החיות שהאורח הנוכחי האכיל אותן
  }
  function showFavoriteAnimal() {
    //ממשו את הלוגיקה שמציגה את החיה שהאורח ביקר הכי הרבה פעמים אצלה
  }